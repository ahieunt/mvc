<?php 
/**
 * 
 */
class SinhvienModel extends DB
{
	
	public function GetSV(){
		return "Nguyen Van A";
	}


	public function Tong($n, $m){
		return $n + $m;
	}

	public function SinhVien(){
		$qr = "SELECT * FROM sinhvien";
		return mysqli_query($this->con, $qr);
	}



}

?>