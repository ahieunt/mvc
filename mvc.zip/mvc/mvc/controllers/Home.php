<?php

/**
 * 
 */
class Home extends Controller
{
	
	function SayHi()
	{	
		$sv = $this->model("SinhvienModel");
		echo $sv->GetSV();
	}

	function Show($a, $b)
	{	
		$sv = $this->model("SinhvienModel");

		$sum = $sv->Tong($a, $b);
		$this->view("aoxau", [
			"Page" => "sinhvien",
			"Number"=>$sum,
			"SV" => $sv->SinhVien()
		]);
	}


}

?>