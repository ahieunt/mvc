<?php


class News
{
	
	function SayHi()
	{
		echo "Home - SayHi";
	}

	function Show($ho, $ten)
	{
		echo $ho. "-" .$ten;
	}


}

?>