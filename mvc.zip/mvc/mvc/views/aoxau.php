<!DOCTYPE html>
<html>
<head>
	<title>Thông tin sinh viên</title>
	<style type="text/css">
		div {padding: 20px;}
		.header, .footer {background: #f00f88;}
	</style>
</head>
<body>
<div class="header"></div>
<div class="content">
	<?php require_once "./mvc/views/pages/".$data["Page"].".php"; ?>
</div>
<div class="footer"></div>
</body>
</html>