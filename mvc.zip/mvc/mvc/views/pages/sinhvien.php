<h2>THÔNG TIN SINH VIÊN</h2>

<style type="text/css">
td, th, tr {padding: 10px; border: 1px solid #ccc;}	

</style>
<table>
	<thead>
		<th>Stt</th>
		<th>Họ và tên</th>
		<th>Năm sinh</th>
		<th>Địa chỉ</th>
	</thead>
	<tbody>
	<?php
		while ($row = mysqli_fetch_array($data["SV"]))
		{ ?>
		<tr>
		<td><?php echo $row["id"]; ?></td>
		<td><?php echo $row["hoten"]; ?></td>
		<td><?php echo $row["namsinh"]; ?></td>
		<td><?php echo $row["diachi"]; ?></td>
		</tr>
		<?php }

	?>
		
	</tbody>
	
</table>