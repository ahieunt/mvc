<!DOCTYPE html>
<html>
<head>
	<title>OK</title>
	<style type="text/css">
		div {padding: 20px;}
		.header, .footer {background: #ccc;}
	</style>
</head>
<body>
<div class="header"></div>
<div class="content">
	<?php require_once "./mvc/views/pages/".$data["Page"].".php"; ?>
</div>
<div class="footer"></div>
</body>
</html>