<h2>Form Register</h2>
<form action="./Register/KhachHangDangKy" method="POST">

  <div class="form-group">
    <label>Username</label>
    <input type="text" name="username" class="form-control" id="username" placeholder="Username">
  </div>
  <div class="form-group">
    <label>Password</label>
    <input type="password" name="password" class="form-control" id="password" placeholder="Password">
  </div>
  <div class="form-group">
    <label>Ho ten</label>
    <input type="text" name="hoten" class="form-control" id="hoten" placeholder="Ho va ten">
  </div>

  <button type="submit" name="btnRegister" class="btn btn-primary">Register</button>
</form>
<?php if(isset($data["result"])) { ?> 
<h3>
	<?php 
		if($data["result"] == true) {
			echo "Dang ky thanh cong";
		}else {
			echo "Dang ky that bai";
		}
	?>
</h3>
<?php } ?>