<h1>Category</h1>
<ul>
<?php
while ($row = mysqli_fetch_array($data["category"]))
		{ ?>
		<li>
		<?php echo $row["id"]; ?>
		<?php echo $row["title"]; ?>
		<?php echo $row["description"]; ?>
		<?php echo $row["slug"]; ?>
		</li>
		<?php } ?>
</ul>