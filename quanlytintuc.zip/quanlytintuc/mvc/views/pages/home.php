<H1>HOME</H1>
<ul>
<?php
while ($row = mysqli_fetch_array($data["category"]))
		{ ?>
		<li>
		<b><?php echo $row["title"]; ?></b>
		(<?php echo $row["description"]; ?>)
		<?php //echo $row["slug"]; ?>
		</li>
		<?php } ?>
</ul>