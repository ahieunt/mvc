<ul>
	<li>
		<a href="./login">Login</a>
	</li>
	<li>
		<a href="./register">Register</a>
	</li>
</ul>
<ul class="category">
	<?php
		//$mangCategory = json_decode($data("categorys"));
		//foreach ($mangCategory as $cat) { ?>
		<li>
			<a href="#">
				<?php //echo $cat->title; ?>
			</a>
		</li>
	<?php//	}
	?>
	</ul>