<?php
/**
 * 
 */
class UserModel extends DB
{
	
	public function InsertNewUser($username, $password, $hoten)
	{
		$qr = "INSERT INTO users VALUES(null, '$username', '$password', '$hoten')";


		$result = false;
		if(mysqli_query($this->con, $qr)){
			$result = true;
		}

		return json_encode($result);
	}
}

?>