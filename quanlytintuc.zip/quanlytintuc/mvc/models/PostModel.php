<?php 
/**
 * 
 */
class PostModel extends DB
{

	public function ListAll(){
		$qr = "SELECT * FROM posts";
		$rows = mysqli_query($this->con, $qr);
		$mang = array();

		while ($row = mysqli_fetch_array($rows)) {
			$mang[] = $row;
		}


		return json_encode($mang);
	}



}

?>