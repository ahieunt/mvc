<?php


class Register extends Controller
{
	public $CategoryModel;
	public $PostModel;
	public $UserModel;

	public function __construct()
	{
		# Model
		$this->CategoryModel = $this->model("CategoryModel");
		$this->PostModel = $this->model("PostModel");
		$this->UserModel = $this->model("UserModel");
	}

	public function SayHi()
	{
		$this->view("layout-2col-left", [
			"page" => "register",
			"categorys" => $this->CategoryModel->ListAll(), 
			"post" => $this->PostModel->ListAll()
			
		]);
	}

	public function KhachHangDangKy()
	{
		// get data khach hang nhap
		if(isset($_POST["btnRegister"])){
			$username = $_POST["username"];
			$password = $_POST["password"];
			$password = password_hash($password, PASSWORD_DEFAULT);
			$hoten = $_POST["hoten"];
			//echo $password;
			// insert data bang users
		$kq = $this->UserModel->InsertNewUser($username, $password, $hoten);

			//echo $kq;

		// thong bao thanh cong hay that bai
			$this->view("layout-2col-left", [
			"page" => "register",
			"categorys" => $this->CategoryModel->ListAll(), 
			"post" => $this->PostModel->ListAll(),
			"result" => $kq
			
		]);
		}

		
	}


}

?>