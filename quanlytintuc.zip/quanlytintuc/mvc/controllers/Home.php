<?php

/**
 * 
 */
class Home extends Controller
{	
	public $CategoryModel;
	public $PostModel;

	public function __construct()
	{
		# Model
		$this->CategoryModel = $this->model("CategoryModel");
		$this->PostModel = $this->model("PostModel");
	}
	
	public function SayHi()
	{	
		$this->view("layout-2col-left", [
			"page" => "home",
			"category" => $this->CategoryModel->ListAll(),
			"post" => $this->PostModel->ListAll()
		]);
	}



}

?>